import { createClient } from "@/lib/supabase/server";
import Home from "@/components/Home";

export default async function Page() {
  const supabase = await createClient();
  const { data: cuts } = await supabase
    .from("portfolio_items")
    .select("id,title,description,image_url,barber_id,profiles:barber_id(display_name,city),services(name,price)")
    .eq("is_public", true)
    .order("created_at", { ascending: false })
    .limit(30);

  const { data: barbers } = await supabase
    .from("profiles")
    .select("id,display_name,avatar_url,city,bio,is_barber,verified")
    .eq("is_barber", true)
    .eq("is_public", true)
    .order("created_at", { ascending: false })
    .limit(12);

  return <Home cuts={cuts ?? []} barbers={barbers ?? []} />;
}