import { createClient } from "@/lib/supabase/server";
import BookingsClient from "@/components/BookingsClient";

export default async function BookingsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return <BookingsClient bookings={[]} authenticated={false} />;
  const { data } = await supabase
    .from("bookings")
    .select("id,start_at,end_at,status,notes,barber_id,client_id,services(name,price),barber:barber_id(display_name,city)")
    .or(`client_id.eq.${user.id},barber_id.eq.${user.id}`)
    .order("start_at", { ascending: true });
  return <BookingsClient bookings={data ?? []} authenticated={true} />;
}