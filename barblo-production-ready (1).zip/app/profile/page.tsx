import { createClient } from "@/lib/supabase/server";
import ProfileClient from "@/components/ProfileClient";

export default async function ProfilePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return <ProfileClient user={user ? { id: user.id, email: user.email ?? "" } : null} />;
}