import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Barblo — Find your barber",
  description: "Discover real haircut work, find the right barber, and book."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}