import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

  const body = await req.json();
  const { barberId, serviceId, startAt, endAt, notes } = body;
  if (!barberId || !serviceId || !startAt || !endAt) {
    return NextResponse.json({ error: "Missing booking fields" }, { status: 400 });
  }
  if (new Date(startAt).getTime() >= new Date(endAt).getTime()) {
    return NextResponse.json({ error: "Invalid time range" }, { status: 400 });
  }

  const { data, error } = await supabase.rpc("create_booking", {
    p_barber_id: barberId,
    p_client_id: user.id,
    p_service_id: serviceId,
    p_start_at: startAt,
    p_end_at: endAt,
    p_notes: notes ?? null
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 409 });
  return NextResponse.json({ booking: data });
}