# Barblo deployment

## Backend / database
The Supabase project is already provisioned and the Barblo schema/RLS migration has been applied.
Supabase URL:
https://gphmefejeqvlemzvmade.supabase.co

The database includes:
- profiles
- services
- portfolio
- availability
- booking + overlap protection
- saved cuts
- follows
- reviews
- community posts/comments
- messages
- notifications
- storage buckets and RLS policies

## Authentication
Enable Email OTP in Supabase Auth and configure the email template to send the OTP code.
Set the production Site URL to:
https://barblo.netlify.app

Add the Netlify URL as an allowed redirect/site URL.

## Netlify
A Netlify project named `barblo` has been created.
Environment variables already configured there:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY
- NEXT_PUBLIC_SITE_URL

The Netlify project currently has no source deployment attached because the hosting connector cannot upload a local ZIP directly. Deploy this repository from Git or run the Netlify CLI from this project directory.

## Security
Never add a Supabase service-role key to the browser or this ZIP.
The publishable/anon key is intended for browser use with RLS enabled.
Do not commit `.env.local`.

## Production checks before launch
- Configure custom SMTP/email sender and rate limits.
- Enable CAPTCHA/abuse protection as appropriate.
- Configure database backups/PITR.
- Add error monitoring and uptime alerts.
- Add image validation/moderation and file-size limits.
- Add cursor pagination for large feeds.
- Add geospatial indexes/search for nearby discovery.
- Load-test search, feeds, messaging and booking.
- Add cancellation/reschedule policies and timezone-aware availability UI.
- Add moderation/report/block flows before opening community features broadly.
