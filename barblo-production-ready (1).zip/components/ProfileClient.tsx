use client";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/browser";

export default function ProfileClient({user}:{user:{id:string;email:string}|null}) {
  const router=useRouter(); const supabase=createClient();
  async function signOut(){await fetch("/api/auth/signout",{method:"POST"}); router.push("/"); router.refresh();}
  if(!user) return <main className="authPage"><div className="authBox"><h1>Your profile.</h1><p className="lede small">Sign in to manage saved cuts, appointments, reviews and your barber profile.</p><a className="button wide" href="/auth">Sign in</a></div></main>;
  return <main className="authPage"><div className="authBox"><a className="logo" href="/">barblo<span>®</span></a><p className="eyebrow">PROFILE</p><h1>{user.email}</h1><p className="lede small">Your account is connected to Barblo. Add profile and barber details from the app as the product grows.</p><a className="button wide" href="/bookings">View bookings</a><button className="textButton" onClick={signOut}>Sign out</button></div></main>;
}