use client";

import Image from "next/image";
import Link from "next/link";
import Nav from "./Nav";
import { useMemo, useState } from "react";

type Cut = {
  id: string; title: string; description?: string | null; image_url: string;
  barber_id: string; profiles?: { display_name?: string; city?: string } | null;
};
type Barber = {
  id: string; display_name: string; avatar_url?: string | null; city?: string | null;
  bio?: string | null; is_barber?: boolean; verified?: boolean;
};

export default function Home({ cuts, barbers }: { cuts: Cut[]; barbers: Barber[] }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const filtered = useMemo(() => cuts.filter(c => {
    const hay = `${c.title} ${c.description ?? ""} ${c.profiles?.display_name ?? ""}`.toLowerCase();
    return (!query || hay.includes(query.toLowerCase())) && (filter === "all" || hay.includes(filter));
  }), [cuts, query, filter]);

  return <><div className="demo">LIVE PRODUCT · DATABASE-BACKED</div><Nav />
    <main>
      <section className="hero">
        <div className="heroCopy">
          <p className="eyebrow">YOUR NEXT CUT STARTS HERE</p>
          <h1>Find the cut.<br /><i>Find the barber.</i></h1>
          <p className="lede">Discover real work from barbers near you. Save the cut you want, meet the person who can do it, and book.</p>
          <div className="search">
            <div><label>WHAT ARE YOU LOOKING FOR?</label><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Low taper, textured crop, scissor cut…" /></div>
            <div><label>WHERE?</label><input placeholder="Your city or area" /></div>
            <button onClick={()=>document.getElementById("discover")?.scrollIntoView({behavior:"smooth"})}>Search</button>
          </div>
        </div>
        <div className="heroPhoto" />
      </section>

      <section id="discover" className="section">
        <div className="sectionHead"><div><p className="eyebrow">DISCOVER</p><h2>Start with the haircut.</h2></div><span className="muted">{filtered.length} real posts</span></div>
        <div className="chips">{["all","taper","fade","curly","scissor","beard"].map(x=><button key={x} className={`chip ${filter===x?"active":""}`} onClick={()=>setFilter(x)}>{x[0].toUpperCase()+x.slice(1)}</button>)}</div>
        {filtered.length ? <div className="masonry">{filtered.map(c=><article className="cut" key={c.id}>
          <Image src={c.image_url} alt={c.title} width={900} height={1100} unoptimized />
          <div className="cutInfo"><div><b>{c.title}</b><div className="muted">{c.profiles?.display_name ?? "Barber"} · {c.profiles?.city ?? "Location not set"}</div></div><button aria-label="Save haircut" className="save">♡</button></div>
        </article>)}</div> : <div className="empty">No published work matches that search yet.</div>}
      </section>

      <section className="statement"><p className="eyebrow">THE PRODUCT LOOP</p><h2>See the work first.<br /><i>Then choose the person.</i></h2></section>

      <section id="barbers" className="section"><div className="sectionHead"><div><p className="eyebrow">BARBERS</p><h2>People worth knowing.</h2></div><Link href="/auth">Join as a barber →</Link></div>
        {barbers.length ? <div className="barberGrid">{barbers.map(b=><article className="barber" key={b.id}>
          {b.avatar_url ? <Image src={b.avatar_url} alt={b.display_name} width={700} height={700} unoptimized /> : <div className="avatarPlaceholder" />}
          <h3>{b.display_name}{b.verified ? " ✓" : ""}</h3><p>{b.city ?? "Location not set"}</p><div>{b.bio ?? "Barber profile coming soon."}</div>
        </article>)}</div> : <div className="empty">No public barber profiles yet. Be one of the first.</div>}
      </section>

      <section id="community" className="statement"><p className="eyebrow">FOR BARBERS</p><h2>Show your work.<br />Get discovered.<br /><i>Build your reputation.</i></h2></section>
    </main>
    <footer><span>barblo®</span><span>Haircut-first discovery.</span></footer>
  </>;
}