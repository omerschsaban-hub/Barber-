import Link from "next/link";

export default function Nav() {
  return <header className="nav">
    <Link href="/" className="logo">barblo<span>®</span></Link>
    <nav>
      <Link href="/#discover">Discover</Link>
      <Link href="/#barbers">Barbers</Link>
      <Link href="/#community">Community</Link>
      <Link href="/bookings">Bookings</Link>
      <Link href="/profile">Profile</Link>
    </nav>
    <Link href="/auth" className="button">Find a barber</Link>
  </header>;
}