use client";

import { createClient } from "@/lib/supabase/browser";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Auth() {
  const supabase = createClient();
  const router = useRouter();
  const [email,setEmail]=useState(""); const [code,setCode]=useState("");
  const [sent,setSent]=useState(false); const [busy,setBusy]=useState(false); const [error,setError]=useState("");

  async function sendCode(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const { error } = await supabase.auth.signInWithOtp({ email: email.trim().toLowerCase(), options: { shouldCreateUser: true }});
    if (error) setError(error.message); else setSent(true);
    setBusy(false);
  }
  async function verify(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const { error } = await supabase.auth.verifyOtp({ email: email.trim().toLowerCase(), token: code.trim(), type: "email" });
    if (error) setError(error.message); else router.push("/");
    setBusy(false);
  }

  return <main className="authPage"><div className="authBox">
    <a className="logo" href="/">barblo<span>®</span></a>
    {!sent ? <><p className="eyebrow">SIGN IN</p><h1>Welcome back.</h1><p className="lede small">Enter your email. We'll send you a one-time code. No password to remember.</p>
      <form onSubmit={sendCode}><label>Email<input required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" /></label><button className="button wide" disabled={busy}>{busy?"Sending…":"Email me a code"}</button></form>
    </> : <><p className="eyebrow">CHECK YOUR EMAIL</p><h1>Enter your code.</h1><p className="lede small">We sent a one-time code to <b>{email}</b>.</p>
      <button className="button wide gmail" onClick={()=>window.open("https://mail.google.com/mail/u/0/#search/from%3A%28noreply%29","_blank","noopener,noreferrer")}>Open Gmail</button>
      <form onSubmit={verify}><label>6-digit code<input required inputMode="numeric" maxLength={8} value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,""))} placeholder="123456" /></label><button className="button wide" disabled={busy}>{busy?"Checking…":"Verify and continue"}</button></form>
      <button className="textButton" onClick={()=>setSent(false)}>Use another email</button>
    </>}
    {error && <p className="error" role="alert">{error}</p>}
  </div></main>;
}