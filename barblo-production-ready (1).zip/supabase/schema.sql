-- Barblo production schema for Supabase/Postgres.
-- Run in the Supabase SQL editor, then configure Auth email OTP.
create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create type public.booking_status as enum ('pending','confirmed','completed','cancelled','no_show');
create type public.post_category as enum ('cuts','techniques','education','business','tools','jobs','events');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  avatar_url text,
  bio text,
  city text,
  phone text,
  phone_public boolean not null default false,
  is_barber boolean not null default false,
  is_public boolean not null default true,
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.services (
  id uuid primary key default gen_random_uuid(),
  barber_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  description text,
  price numeric(10,2) not null check (price >= 0),
  duration_minutes int not null check (duration_minutes between 5 and 480),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.portfolio_items (
  id uuid primary key default gen_random_uuid(),
  barber_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  image_url text not null,
  hair_type text,
  tags text[] not null default '{}',
  is_public boolean not null default true,
  created_at timestamptz not null default now()
);
create index portfolio_search_idx on public.portfolio_items using gin(tags);
create index portfolio_barber_idx on public.portfolio_items(barber_id, created_at desc);

create table public.availability_rules (
  id uuid primary key default gen_random_uuid(),
  barber_id uuid not null references public.profiles(id) on delete cascade,
  weekday int not null check (weekday between 0 and 6),
  start_time time not null,
  end_time time not null,
  active boolean not null default true,
  check (start_time < end_time)
);

create table public.availability_blocks (
  id uuid primary key default gen_random_uuid(),
  barber_id uuid not null references public.profiles(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  check (starts_at < ends_at)
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  barber_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid not null references public.services(id) on delete restrict,
  start_at timestamptz not null,
  end_at timestamptz not null,
  status public.booking_status not null default 'pending',
  notes text,
  created_at timestamptz not null default now(),
  check (start_at < end_at),
  check (client_id <> barber_id)
);
create index bookings_barber_time_idx on public.bookings(barber_id,start_at);
create index bookings_client_time_idx on public.bookings(client_id,start_at);
alter table public.bookings add constraint no_overlapping_active_bookings
exclude using gist (
  barber_id with =,
  tstzrange(start_at,end_at,'[)') with &&
) where (status in ('pending','confirmed'));

create table public.saved_portfolio (
  user_id uuid references public.profiles(id) on delete cascade,
  portfolio_id uuid references public.portfolio_items(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, portfolio_id)
);

create table public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check(follower_id <> following_id)
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid unique not null references public.bookings(id) on delete cascade,
  client_id uuid not null references public.profiles(id) on delete cascade,
  barber_id uuid not null references public.profiles(id) on delete cascade,
  overall smallint not null check(overall between 1 and 5),
  fade smallint check(fade between 1 and 5),
  scissor smallint check(scissor between 1 and 5),
  beard smallint check(beard between 1 and 5),
  body text,
  created_at timestamptz not null default now()
);

create table public.community_posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  category public.post_category not null,
  body text not null check(length(body) between 1 and 5000),
  image_url text,
  created_at timestamptz not null default now()
);
create index community_posts_created_idx on public.community_posts(created_at desc);

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_key text not null,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  body text not null check(length(body) between 1 and 5000),
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index messages_conversation_idx on public.messages(conversation_key,created_at);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  payload jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id, display_name)
  values(new.id, coalesce(new.raw_user_meta_data->>'name', split_part(coalesce(new.email,''),'@',1)));
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.create_booking(
  p_barber_id uuid,p_client_id uuid,p_service_id uuid,
  p_start_at timestamptz,p_end_at timestamptz,p_notes text
) returns public.bookings
language plpgsql security definer set search_path=public as $$
declare result public.bookings;
begin
  if p_client_id <> auth.uid() then raise exception 'Not authorized'; end if;
  if p_start_at >= p_end_at then raise exception 'Invalid time'; end if;
  if not exists(select 1 from profiles where id=p_barber_id and is_barber=true and is_public=true) then
    raise exception 'Barber unavailable';
  end if;
  if not exists(select 1 from services where id=p_service_id and barber_id=p_barber_id and active=true) then
    raise exception 'Service unavailable';
  end if;
  if exists(select 1 from bookings where barber_id=p_barber_id and status in ('pending','confirmed')
            and tstzrange(start_at,end_at,'[)') && tstzrange(p_start_at,p_end_at,'[)')) then
    raise exception 'That time is no longer available';
  end if;
  insert into bookings(client_id,barber_id,service_id,start_at,end_at,notes)
  values(p_client_id,p_barber_id,p_service_id,p_start_at,p_end_at,p_notes)
  returning * into result;
  return result;
end $$;

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.portfolio_items enable row level security;
alter table public.availability_rules enable row level security;
alter table public.availability_blocks enable row level security;
alter table public.bookings enable row level security;
alter table public.saved_portfolio enable row level security;
alter table public.follows enable row level security;
alter table public.reviews enable row level security;
alter table public.community_posts enable row level security;
alter table public.comments enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;

create policy "public profiles readable" on profiles for select using (is_public=true or id=auth.uid());
create policy "own profile insert" on profiles for insert with check(id=auth.uid());
create policy "own profile update" on profiles for update using(id=auth.uid()) with check(id=auth.uid());

create policy "active services public" on services for select using (
  active=true or barber_id=auth.uid()
);
create policy "barber manages services" on services for all using(barber_id=auth.uid()) with check(barber_id=auth.uid());

create policy "public portfolio readable" on portfolio_items for select using(is_public=true or barber_id=auth.uid());
create policy "barber manages portfolio" on portfolio_items for all using(barber_id=auth.uid()) with check(barber_id=auth.uid());

create policy "barber availability readable" on availability_rules for select using(active=true or barber_id=auth.uid());
create policy "barber manages availability" on availability_rules for all using(barber_id=auth.uid()) with check(barber_id=auth.uid());
create policy "barber blocks readable" on availability_blocks for select using(barber_id=auth.uid());
create policy "barber manages blocks" on availability_blocks for all using(barber_id=auth.uid()) with check(barber_id=auth.uid());

create policy "participants read bookings" on bookings for select using(client_id=auth.uid() or barber_id=auth.uid());
create policy "participants update bookings" on bookings for update using(client_id=auth.uid() or barber_id=auth.uid());
create policy "clients create own booking" on bookings for insert with check(client_id=auth.uid());

create policy "users manage saves" on saved_portfolio for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "follows readable" on follows for select using(true);
create policy "users manage follows" on follows for all using(follower_id=auth.uid()) with check(follower_id=auth.uid());

create policy "reviews readable" on reviews for select using(true);
create policy "clients write reviews" on reviews for insert with check(client_id=auth.uid() and exists(
  select 1 from bookings b where b.id=booking_id and b.client_id=auth.uid() and b.barber_id=reviews.barber_id and b.status='completed'
));

create policy "community public read" on community_posts for select using(true);
create policy "authors manage community posts" on community_posts for all using(author_id=auth.uid()) with check(author_id=auth.uid());
create policy "comments public read" on comments for select using(true);
create policy "authors manage comments" on comments for all using(author_id=auth.uid()) with check(author_id=auth.uid());

create policy "message participants read" on messages for select using(sender_id=auth.uid() or recipient_id=auth.uid());
create policy "sender creates message" on messages for insert with check(sender_id=auth.uid());
create policy "recipient marks message read" on messages for update using(recipient_id=auth.uid());

create policy "own notifications" on notifications for select using(user_id=auth.uid());
create policy "own notifications update" on notifications for update using(user_id=auth.uid());