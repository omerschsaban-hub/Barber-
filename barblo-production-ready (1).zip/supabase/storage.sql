-- Create storage buckets after the schema.
insert into storage.buckets (id,name,public) values
  ('avatars','avatars',true),
  ('portfolio','portfolio',true),
  ('community','community',true)
on conflict (id) do nothing;

-- Public read is intentional for published profile/portfolio/community images.
create policy "public image read" on storage.objects for select using(bucket_id in ('avatars','portfolio','community'));

create policy "users upload own images" on storage.objects for insert to authenticated
with check(bucket_id in ('avatars','portfolio','community') and (storage.foldername(name))[1] = auth.uid()::text);

create policy "users update own images" on storage.objects for update to authenticated
using((storage.foldername(name))[1] = auth.uid()::text)
with check((storage.foldername(name))[1] = auth.uid()::text);

create policy "users delete own images" on storage.objects for delete to authenticated
using((storage.foldername(name))[1] = auth.uid()::text);