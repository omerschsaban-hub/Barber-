-- Optional taxonomy data. These are product terms, not fake users.
create table if not exists public.style_taxonomy (
  slug text primary key,
  name text not null,
  created_at timestamptz not null default now()
);
insert into public.style_taxonomy(slug,name) values
('low-taper','Low taper'),('skin-fade','Skin fade'),('textured-crop','Textured crop'),
('buzz-cut','Buzz cut'),('scissor-cut','Scissor cut'),('beard','Beard'),
('curly','Curly'),('pompadour','Pompadour'),('fade','Fade'),('taper','Taper')
on conflict (slug) do nothing;