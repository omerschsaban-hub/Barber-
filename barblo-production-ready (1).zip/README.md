# Barblo — full-stack foundation

This ZIP upgrades the original four-file prototype into a deployable Next.js + Supabase application foundation while preserving the haircut-first product direction.

## Included

- Next.js App Router + TypeScript
- Supabase email OTP authentication
- One-time code login with an **Open Gmail** button
- Server-side Supabase client + auth middleware
- PostgreSQL schema
- Row Level Security policies
- Storage buckets and storage policies
- Barber profiles
- Services
- Portfolio
- Availability rules/blocks
- Bookings with a PostgreSQL exclusion constraint to prevent overlapping active bookings
- Saves
- Follows
- Reviews restricted to completed bookings
- Community posts/comments
- Messaging model
- Notifications model
- Production-oriented environment configuration
- Original design direction rebuilt with only Ink (#111111) and Warm Cream (#F5F1E8)

## Setup

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL editor.
3. Run `supabase/storage.sql`.
4. In Supabase Auth, enable Email OTP. Configure the email template so it includes the OTP token/code.
5. Copy `.env.example` to `.env.local` and add the Supabase URL and anon key.
6. Run:
   `npm install`
   `npm run dev`
7. Deploy the repository to Vercel and add the same environment variables.
8. In Supabase Auth URL settings, add your production Vercel URL as an allowed redirect/site URL.

## Gmail

The Open Gmail button only opens Gmail. It does not grant Barblo access to a user's mailbox and should not request Gmail permissions just for login.

## Important production hardening

Before public launch:
- configure a custom email sender/domain and appropriate rate limits in Supabase Auth
- enable CAPTCHA/abuse protection where appropriate
- configure backups/PITR on the database
- use a real transactional email provider/domain
- add image size/type validation and malware/content moderation before accepting public uploads
- add server-side authorization for every mutation
- add monitoring/error tracking and uptime alerts
- load-test search, feeds, messaging and booking paths
- add pagination/cursors to every unbounded feed
- add geospatial indexing/search when location search is enabled
- never expose the Supabase service-role key to the browser
- keep `.env.local` out of Git
- replace demo photography with properly licensed/user-owned images

## What is deliberately not faked

There are no seeded fake reviews, fake bookings, fake users or fake ratings presented as production data. Empty states are shown until real users create data.

## Deploy

GitHub → Vercel → Supabase is the intended production path.
