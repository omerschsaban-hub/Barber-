# Barblo

A self-contained frontend prototype implementing the Barblo product thesis:
- haircut-first discovery
- barber profiles and portfolio
- booking/contact interaction prototypes
- barber community
- local marketplace bottleneck dashboard
- demo data clearly labeled

## Run
Open `index.html` in a browser, or serve the folder with any static HTTP server.

## Important
The included photography URLs are remote demo references. Before production, replace them with images whose licensing permits your intended use and store source/creator/license metadata. The current prototype intentionally does not scrape Google Images.

## Production next step
Connect authentication, a database, storage, real booking availability, messaging, reviews, moderation and analytics while preserving the same design system and bottleneck-first architecture.
